import os
from flask import Flask, render_template, request, redirect, url_for, flash, make_response
from werkzeug.utils import secure_filename
from datetime import datetime
import uuid
import google.generativeai as genai
from dotenv import load_dotenv
from fpdf import FPDF

load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'dev-secret-key')
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['ALLOWED_EXTENSIONS'] = {'pdf', 'png', 'jpg', 'jpeg', 'txt'}

# Configure Gemini
GEMINI_API_KEY = os.getenv('GEMINI_API_KEY')
if not GEMINI_API_KEY:
    print("ERROR: Missing Gemini API Key in .env file")
    exit(1)
genai.configure(api_key=GEMINI_API_KEY)

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

def extract_text_from_file(filepath):
    """Mock function - replace with actual text extraction"""
    return f"Sample text from {os.path.basename(filepath)}. Replace with actual PDF/image text extraction."

def generate_quiz(text, num_questions=10, quiz_type="multiple_choice"):
    try:
        model = genai.GenerativeModel('gemini-2.0-flash')
        
        prompt = f"""Generate {num_questions} {quiz_type} questions from this text:
{text}

For each question, provide:
1. The question text
2. Four answer options (A-D)
3. The correct answer
4. A brief explanation of why it's correct

Format each question exactly like this:
[QUESTION]
Q1. [Question text]
[OPTIONS]
A) [Option 1]
B) [Option 2]
C) [Option 3]
D) [Option 4]
[CORRECT ANSWER]
Correct: [Letter]
[EXPLANATION]
Explanation: [Brief explanation]"""
        
        response = model.generate_content(prompt)
        return parse_quiz_response(response.text)
    except Exception as e:
        return [f"Error generating questions: {str(e)}"]

def parse_quiz_response(response_text):
    questions = []
    current_question = {}
    lines = response_text.split('\n')
    
    for line in lines:
        line = line.strip()
        if line.startswith('Q'):
            if current_question:
                questions.append(current_question)
            current_question = {
                'question': line,
                'options': [],
                'correct': '',
                'explanation': ''
            }
        elif line.startswith(('A)', 'B)', 'C)', 'D)')):
            current_question['options'].append(line)
        elif line.startswith('Correct:'):
            current_question['correct'] = line.split(':')[1].strip()
        elif line.startswith('Explanation:'):
            current_question['explanation'] = line.split(':', 1)[1].strip()
    
    if current_question:
        questions.append(current_question)
    
    return questions

def generate_pdf(questions):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    
    pdf.cell(200, 10, txt="Generated Quiz (With Answers)", ln=1, align='C')
    pdf.ln(10)
    
    for i, q in enumerate(questions, 1):
        pdf.cell(0, 10, txt=f"Q{i}. {q['question']}", ln=1)
        for opt in q['options']:
            pdf.cell(0, 10, txt=f"  {opt}", ln=1)
        pdf.set_text_color(0, 128, 0)
        pdf.cell(0, 10, txt=f"  Correct Answer: {q['correct']}", ln=1)
        pdf.set_text_color(0, 0, 0)
        pdf.cell(0, 10, txt=f"  Explanation: {q['explanation']}", ln=1)
        pdf.ln(5)
    
    return pdf.output(dest='S').encode('latin1')

@app.route('/download', methods=['POST'])
def download_pdf():
    try:
        data = request.get_json()
        questions = []
        
        for i in range(1, int(data['num_questions']) + 1):
            questions.append({
                'question': data[f'q{i}_text'],
                'options': [
                    data[f'q{i}_A'],
                    data[f'q{i}_B'],
                    data[f'q{i}_C'],
                    data[f'q{i}_D']
                ],
                'correct': data[f'q{i}_correct'],
                'explanation': data[f'q{i}_explanation']
            })
        
        pdf = generate_pdf(questions)
        response = make_response(pdf)
        response.headers['Content-Type'] = 'application/pdf'
        response.headers['Content-Disposition'] = 'attachment; filename=quiz_with_answers.pdf'
        return response
    except Exception as e:
        return str(e), 400

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        text = request.form.get('notes', '')
        file = request.files.get('file')
        num_questions = int(request.form.get('question_count', 10))
        quiz_type = request.form.get('quiz_type', 'multiple_choice')
        
        if file and file.filename != '' and allowed_file(file.filename):
            filename = secure_filename(f"{uuid.uuid4()}_{file.filename}")
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            text = extract_text_from_file(filepath)
            os.remove(filepath)
        
        if text:
            questions = generate_quiz(text, num_questions, quiz_type)
            if questions and not isinstance(questions[0], str):
                return render_template('quiz.html', 
                                    questions=questions, 
                                    now=datetime.now(),
                                    num_questions=num_questions,
                                    quiz_type=quiz_type)
            flash(questions[0] if questions else 'Failed to generate questions')
        
        flash('Please provide text or a valid file')
    return render_template('index.html')


# @app.route('/download', methods=['POST'])
# def download_pdf():
#     questions = []
#     for i in range(1, int(request.form['num_questions']) + 1):
#         questions.append({
#             'question': request.form[f'q{i}_text'],
#             'options': [
#                 request.form[f'q{i}_A'],
#                 request.form[f'q{i}_B'],
#                 request.form[f'q{i}_C'],
#                 request.form[f'q{i}_D']
#             ],
#             'correct': request.form[f'q{i}_correct'],
#             'explanation': request.form[f'q{i}_explanation']
#         })
#     pdf = generate_pdf(questions)
#     response = make_response(pdf)
#     response.headers['Content-Type'] = 'application/pdf'
#     response.headers['Content-Disposition'] = 'attachment; filename=quiz_with_answers.pdf'
#     return response

if __name__ == '__main__':
    app.run(debug=True)